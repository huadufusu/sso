package com.sso.login.utils;

import com.sso.login.pojo.User;

import java.util.HashMap;
import java.util.Map;

public class LogCacheUtil {
    public static Map<String, User> loginUser = new HashMap<>();

}
